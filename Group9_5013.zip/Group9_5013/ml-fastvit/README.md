
# FastViT Implementation - README

## Overview

This repository contains the implementation of various FastViT models for classification and segmentation tasks. The codebase allows for training with and without distillation, and includes models such as FastViT-SA12, FastViT-SA24, FastViT-SA36, and FastViT-MA36.

## Newly Developed Code

While the classification task code is sourced from the original paper's GitHub repository, we have developed new code for the segmentation tasks, knowledge distillation, and dynamic convolution.

## Requirements

- Python 3.8 or higher
- PyTorch 1.7 or higher
- CUDA 10.2 or higher (for GPU support)
- Additional Python libraries as listed in `requirements.txt`

## Setup

1. **Install dependencies:**

   ```sh
   pip install -r requirements.txt
   ```

## Data Preparation

Ensure you have the ImageNet dataset prepared in the specified directory structure. Update the paths in the training scripts accordingly.

## Training

### Classification Task

#### FastViT-SA12

- **Without Distillation:**

  ```sh
  python -m torch.distributed.launch --nproc_per_node=1 train.py /path/to/imagenet --model fastvit_sa12 -b 128 --lr 1e-3 --native-amp --mixup 0.2 --output ./results/sa12/without --input-size 3 256 256 --drop-path 0.1
  ```

- **With Distillation:**

  ```sh
  python -m torch.distributed.launch --nproc_per_node=1 train.py /path/to/imagenet --model fastvit_sa12 -b 128 --lr 1e-3 --native-amp --output ./results/sa12/with --input-size 3 256 256 --distillation-type "hard"
  ```

#### FastViT-SA24

- **Without Distillation:**

  ```sh
  python -m torch.distributed.launch --nproc_per_node=1 train.py /path/to/imagenet --model fastvit_sa24 -b 128 --lr 1e-3 --native-amp --mixup 0.2 --output ./results/sa24/without --input-size 3 256 256 --drop-path 0.1
  ```

- **With Distillation:**

  ```sh
  python -m torch.distributed.launch --nproc_per_node=1 train.py /path/to/imagenet --model fastvit_sa24 -b 128 --lr 1e-3 --native-amp --output ./results/sa24/with --input-size 3 256 256 --drop-path 0.05 --distillation-type "hard"
  ```

#### FastViT-SA36

- **Without Distillation:**

  ```sh
  python -m torch.distributed.launch --nproc_per_node=1 train.py /path/to/imagenet --model fastvit_sa36 -b 128 --lr 1e-3 --native-amp --mixup 0.2 --output ./results/sa36/without --input-size 3 256 256 --drop-path 0.2
  ```

- **With Distillation:**

  ```sh
  python -m torch.distributed.launch --nproc_per_node=1 train.py /path/to/imagenet --model fastvit_sa36 -b 64 --lr 1e-3 --native-amp --output ./results/sa36/with --input-size 3 256 256 --drop-path 0.1 --distillation-type "hard"
  ```

#### FastViT-MA36

- **Without Distillation:**

  ```sh
  python -m torch.distributed.launch --nproc_per_node=1 train.py /path/to/imagenet --model fastvit_t8 -b 128 --lr 1e-3 --native-amp --output ./results/ma36/without --input-size 3 256 256 --drop-path 0.35
  ```

- **With Distillation:**

  ```sh
  python -m torch.distributed.launch --nproc_per_node=1 train.py /path/to/imagenet --model fastvit_t8 -b 128 --lr 1e-3 --native-amp --output ./results/ma36/with --input-size 3 256 256 --drop-path 0.2 --distillation-type "hard"
  ```

#### FastViT-S12

- **Without Distillation:**

  ```sh
  python -m torch.distributed.launch --nproc_per_node=1 train.py /path/to/imagenet --model fastvit_s12 -b 128 --lr 1e-3 --native-amp --mixup 0.2 --output ./results/s12/without --input-size 3 256 256
  ```

- **With Distillation:**

  ```sh
  python -m torch.distributed.launch --nproc_per_node=1 train.py /path/to/imagenet --model fastvit_s12 -b 128 --lr 1e-3 --native-amp --mixup 0.2 --output ./results/s12/with --input-size 3 256 256 --distillation-type "hard"
  ```

### Segmentation Task

Replace the model `fastvit` with `fastvit-segmentation` in the above commands.

## Evaluation

### Classification Task

#### FastViT-SA12

```sh
python validate.py /path/to/imagenet --model fastvit_sa12 --checkpoint ./results/sa12/without/checkpoint-0.pth.tar
python validate.py /path/to/imagenet --model fastvit_sa12 --checkpoint ./results/sa12/with/checkpoint-0.pth.tar
```

#### FastViT-SA24

```sh
python validate.py /path/to/imagenet --model fastvit_sa24 --checkpoint ./results/sa24/without/checkpoint-0.pth.tar
python validate.py /path/to/imagenet --model fastvit_sa24 --checkpoint ./results/sa24/with/checkpoint-0.pth.tar
```

#### FastViT-SA36

```sh
python validate.py /path/to/imagenet --model fastvit_sa36 --checkpoint ./results/sa36/without/checkpoint-0.pth.tar
python validate.py /path/to/imagenet --model fastvit_sa36 --checkpoint ./results/sa36/with/checkpoint-0.pth.tar
```

#### FastViT-MA36

```sh
python validate.py /path/to/imagenet --model fastvit_t8 --checkpoint ./results/ma36/without/checkpoint-0.pth.tar
python validate.py /path/to/imagenet --model fastvit_t8 --checkpoint ./results/ma36/with/checkpoint-0.pth.tar
```

#### FastViT-S12

```sh
python validate.py /path/to/imagenet --model fastvit_s12 --checkpoint ./results/s12/without/checkpoint-0.pth.tar
python validate.py /path/to/imagenet --model fastvit_s12 --checkpoint ./results/s12/with/checkpoint-0.pth.tar
```

### Segmentation Task

Replace the model `fastvit` with `fastvit-segmentation` in the above commands.

## Conclusion

This repository provides a comprehensive implementation of FastViT models with support for training and evaluation in both classification and segmentation tasks. The newly developed code for segmentation, knowledge distillation, and dynamic convolution enhances the functionality and extends the capabilities of the original models.

For any issues or contributions, please feel free to create an issue or submit a pull request.
