

**Dynamic Convolution**


    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    
    class DynamicConv2d(nn.Module):
        def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, groups=1, bias=True):
            super(DynamicConv2d, self).__init__()
            self.in_channels = in_channels
            self.out_channels = out_channels
            self.kernel_size = kernel_size
            self.stride = stride
            self.padding = padding
            self.groups = groups
            
        # Define the dynamic weights
        self.weight = nn.Parameter(torch.randn(out_channels, in_channels // groups, kernel_size, kernel_size))
        if bias:
            self.bias = nn.Parameter(torch.randn(out_channels))
        else:
            self.bias = None
    
    def forward(self, x):
        b, c, h, w = x.size()
        dynamic_weight = self.weight.unsqueeze(0).expand(b, -1, -1, -1, -1)
        dynamic_weight = dynamic_weight.view(b * self.out_channels, self.in_channels // self.groups, self.kernel_size, self.kernel_size)
        
        x = x.view(1, b * c, h, w)
        out = F.conv2d(x, dynamic_weight, bias=None, stride=self.stride, padding=self.padding, groups=b * self.groups)
        out = out.view(b, self.out_channels, out.size(-2), out.size(-1))
        
        if self.bias is not None:
       
     from cvnets.layers import Dropout, GlobalPool, LinearLayer
    
    class MobileViT(BaseImageEncoder):
        def __init__(self, opts, *args, **kwargs) -> None:
            num_classes = getattr(opts, "model.classification.n_classes", 1000)
            classifier_dropout = getattr(opts, "model.classification.classifier_dropout", 0.0)
            pool_type = getattr(opts, "model.layer.global_pool", "mean")
            image_channels = 3
            out_channels = 16
            mobilevit_config = get_configuration(opts=opts)
            super().__init__(opts, *args, **kwargs)
    
            self.model_conf_dict = dict()
    
            self.conv_1 = DynamicConv2d(
                in_channels=image_channels,
                out_channels=out_channels,
                kernel_size=3,
                stride=2,
                padding=1,
                bias=False
            )
            self.model_conf_dict["conv1"] = {"in": image_channels, "out": out_channels}
            in_channels = out_channels
    
            self.layer_1, out_channels = self._make_layer(
                opts=opts, input_channel=in_channels, cfg=mobilevit_config["layer1"]
            )
            self.model_conf_dict["layer1"] = {"in": in_channels, "out": out_channels}
            in_channels = out_channels
    
            self.layer_2, out_channels = self._make_layer(
                opts=opts, input_channel=in_channels, cfg=mobilevit_config["layer2"]
            )
            self.model_conf_dict["layer2"] = {"in": in_channels, "out": out_channels}
            in_channels = out_channels
    
            self.layer_3, out_channels = self._make_layer(
                opts=opts, input_channel=in_channels, cfg=mobilevit_config["layer3"]
            )
            self.model_conf_dict["layer3"] = {"in": in_channels, "out": out_channels}
            in_channels = out_channels
    
            self.layer_4, out_channels = self._make_layer(
                opts=opts,
                input_channel=in_channels,
                cfg=mobilevit_config["layer4"],
                dilate=self.dilate_l4,
            )
            self.model_conf_dict["layer4"] = {"in": in_channels, "out": out_channels}
            in_channels = out_channels
    
            self.layer_5, out_channels = self._make_layer(
                opts=opts,
                input_channel=in_channels,
                cfg=mobilevit_config["layer5"],
                dilate=self.dilate_l5,
            )
            self.model_conf_dict["layer5"] = {"in": in_channels, "out": out_channels}
            in_channels = out_channels
    
            exp_channels = min(mobilevit_config["last_layer_exp_factor"] * in_channels, 960)
            self.conv_1x1_exp = DynamicConv2d(
                in_channels=in_channels,
                out_channels=exp_channels,
                kernel_size=1,
                stride=1,
                padding=0,
                bias=False
            )
            self.model_conf_dict["exp_before_cls"] = {"in": in_channels, "out": exp_channels}
    
            self.classifier = nn.Sequential()
            self.classifier.add_module("global_pool", GlobalPool(pool_type=pool_type, keep_dim=False))
            if 0.0 < classifier_dropout < 1.0:
                self.classifier.add_module("dropout", Dropout(p=classifier_dropout, inplace=True))
            self.classifier.add_module("fc", LinearLayer(in_features=exp_channels, out_features=num_classes, bias=True))
    
            self.check_model()
            self.reset_parameters(opts=opts)
    
            out = out + self.bias.view(1, -1, 1, 1)
        return out